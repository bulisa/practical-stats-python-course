Sample datasets for exercises. Replace with real data as needed.
